import test from 'node:test';
import assert from 'node:assert/strict';
import {generateManualPackageEstimate,generatePackageQuote} from '../.runtime-dist/package-search.js';
import {calculatePackageQuote,calculatePartialPackageEstimate} from '../.runtime-dist/pricing.js';
import {createBackendRouter} from '../../src/router.js';
const date = n => new Date(Date.now()+n*86400000).toISOString().slice(0,10);
const start=date(10), end=date(17);
const out={origin:'TAS',destination:'JED',departure_at:start+'T09:00:00+05:00',arrival_at:start+'T12:00:00+03:00'};
const back={origin:'JED',destination:'TAS',departure_at:end+'T09:00:00+03:00',arrival_at:end+'T16:00:00+05:00'};
const room={id:'makkah:0',city:'makkah',hotelId:'h',offerId:'o',roomId:'r',checkin:start,checkout:end,adults:2,children:[]};
const roomMed={...room,id:'madinah:0',city:'madinah',hotelId:'m',offerId:'om',checkin:date(15)};
function fixture(){
 const cache=new Map(), flights=new Map();
 const put=(key,data)=>cache.set(key,{payload:JSON.stringify(data),updated_at:Date.now(),expires_at:Date.now()+600000});
 put('catalog:v1:makkah',[{id:'h',stars:3}]);put('catalog:v1:madinah',[{id:'m',stars:5}]);
 put(`rates:v2:h:${start}:${end}:2::UZ:USD`,[{offerId:'o',roomId:'r',price:700,currency:'USD',mealPlan:'room only'}]);
 put(`rates:v2:m:${date(15)}:${end}:2::UZ:USD`,[{offerId:'om',roomId:'r',price:300,currency:'USD',mealPlan:'room only'}]);
 put(`rates:v2:h:${start}:${date(15)}:3::UZ:USD`,[{offerId:'o3a',roomId:'r',price:600,currency:'USD',mealPlan:'room only'}]);
 put(`rates:v2:m:${date(15)}:${end}:3::UZ:USD`,[{offerId:'om3',roomId:'r',price:400,currency:'USD',mealPlan:'room only'}]);
 for(const [id,legs,fare] of [['out',[out],250],['back',[back],300],['pair',[out,back],550]]) flights.set(id,{id,published:1,currency:'USD',per_traveler_fare:fare,observed_at:new Date().toISOString(),itinerary_json:JSON.stringify({cabin_class:'economy',legs})});
 return {NUITEE_API_KEY:'sand_fixture',HOTELS_DB:{prepare(sql){let args=[];return {bind(...x){args=x;return this},async first(){return sql.includes('curated_flight_offers')?flights.get(args[0])??null:cache.get(args[0])??null},async run(){return{success:true}}}}}};
}
const flight=(id,leg=out)=>({identity:'curated:'+id,origin:leg.origin,destination:leg.destination,departureDate:leg.departure_at.slice(0,10),cabin:'economy'});
const body=(extra={})=>({adults:2,includeMadinah:false,start,end,rooms:[],flights:[],...extra});
const req=(value,path='/api/package/estimate')=>new Request('https://fixture'+path,{method:'POST',body:JSON.stringify(value)});
const send=async(value,env=fixture())=>{const res=await generateManualPackageEstimate(req(value),env);return {status:res.status,body:await res.json()}};
test('no hotel or flight rejects preview, transfer alone is not sufficient',async()=>{const r=await send(body({transferVehicle:'carnival'}));assert.equal(r.status,400);assert.equal(r.body.error,'ESTIMATE_COMPONENT_REQUIRED')});
test('hotel-only and flight-only produce public positive estimates without proof',async()=>{for(const payload of [body({rooms:[room]}),body({flights:[flight('out')]}),body({includeMadinah:true,rooms:[roomMed]})]){const r=await send(payload);assert.equal(r.status,200,JSON.stringify(r.body));const q=r.body.estimate;assert.ok(q.totalPackagePrice>0);assert.equal(q.bookingAllowed,false);assert.deepEqual(Object.keys(q).sort(),['bookingAllowed','currency','isEstimated','pairedFareIncluded','pricePerPerson','provisionalTier','totalPackagePrice'].sort());assert.doesNotMatch(JSON.stringify(r.body),/supplierCost|markup|quoteProof|quoteId|prebookId/)}});
test('same server pricing formula is used with verified selected components',async()=>{const base=body({rooms:[room],flights:[flight('out'),flight('back',back)]});const r=await send(base);assert.equal(r.status,200,JSON.stringify(r.body));const hotel={hotelId:'h',roomId:'r',amountUsd:100,unit:'perRoomNight',nights:7,pricingMode:'fixture'};const full=calculatePackageQuote({tier:'standard',tripType:'roundTrip',includeMadinah:false,travelers:{adults:2,children:0,infants:0,rooms:1},meals:{makkahLunch:false,makkahDinner:false,madinahDinner:false},hotelMealComponents:[],transferVehicle:null,includeHaramainTrain:false,haramainFareClass:'economy',haramainTicketCount:0,journeyFare:{candidateId:'fixture',amount:1100,currency:'USD',fareScope:'totalParty',providerId:'fixture',observedAt:new Date().toISOString(),travelDate:start,normalizedGroupUsd:1100},makkahHotel:hotel,madinahHotel:null});assert.equal(r.body.estimate.totalPackagePrice,full.totalPackagePrice)});
test('paired fare is counted once and flagged if only one leg is selected',async()=>{const single=await send(body({flights:[flight('pair')]})),both=await send(body({flights:[flight('pair'),flight('pair',back)]}));assert.equal(single.status,200,JSON.stringify(single.body));assert.equal(both.status,200,JSON.stringify(both.body));assert.equal(single.body.estimate.totalPackagePrice,both.body.estimate.totalPackagePrice);assert.equal(single.body.estimate.pairedFareIncluded,true);assert.equal(both.body.estimate.pairedFareIncluded,false)});
test('invalid route, tampered rate, cabin and unmatched pair reject; client price is ignored',async()=>{for(const payload of [body({rooms:[{...room,offerId:'forged'}]}),body({flights:[{...flight('out'),departureDate:date(11)}]}),body({flights:[{...flight('out'),cabin:'business'}]}),body({flights:[flight('pair'),flight('back',back)]}),body({rooms:[roomMed]})])assert.equal((await send(payload)).status,400);const a=await send(body({flights:[flight('out')]})),b=await send(body({flights:[{...flight('out'),price:1}],totalPackagePrice:1}));assert.equal(a.body.estimate.totalPackagePrice,b.body.estimate.totalPackagePrice)});
test('full quote still requires full components and the existing cutover gate remains intact',async()=>{const direct=await generatePackageQuote(req(body({rooms:[room]}),'/api/package/quote'),fixture());assert.equal(direct.status,400);const dummy={fetch:()=>new Response('unexpected')};const router=createBackendRouter({hotels:dummy,flights:dummy,packages:{fetch:generateManualPackageEstimate}});assert.equal((await router.fetch(req(body({rooms:[room]}),'/api/package/quote'),fixture(),{})).status,503);const res=await router.fetch(req(body({rooms:[room]})),fixture(),{});assert.equal(res.status,200,await res.clone().text());assert.equal((await res.json()).estimate.bookingAllowed,false)});

test('first room can fill entire selected window before the other city is picked',async()=>{const r=await send(body({includeMadinah:true,rooms:[room]}));assert.equal(r.status,200,JSON.stringify(r.body));assert.ok(r.body.estimate.totalPackagePrice>0)});
test('optional Haramain fare is computed by server, not supplied by client',async()=>{const a=body({includeMadinah:true,rooms:[room],transferVehicle:'carnival'});const baseline=await send(a),train=await send({...a,haramain:{enabled:true,fareClass:'economy',ticketCount:2,price:1}});assert.equal(baseline.status,200);assert.equal(train.status,200,JSON.stringify(train.body));assert.ok(train.body.estimate.totalPackagePrice>baseline.body.estimate.totalPackagePrice);assert.equal(train.body.estimate.bookingAllowed,false)});
test('verified Aviasales one-way selection can be priced independently',async()=>{const env={...fixture(),TRAVELPAYOUTS_API_TOKEN:'test'};const saved=globalThis.fetch;globalThis.fetch=async()=>Response.json({success:true,currency:'usd',data:[{origin:'TAS',destination:'JED',airline:'HY',flight_number:'335',departure_at:start+'T09:00:00+05:00',duration:360,price:300}]});try{const r=await send(body({flights:[{...flight('out'),identity:`aviasales:ow:TAS:JED:${start}:-:HY:335:-:-`}]}),env);assert.equal(r.status,200,JSON.stringify(r.body));assert.equal(r.body.estimate.bookingAllowed,false)}finally{globalThis.fetch=saved}});

test('manual six adults price two rooms per city and partial estimates',async()=>{
 const a={...room,offerId:'o3a',adults:3,checkout:date(15)};
 const b={...roomMed,offerId:'om3',adults:3};
 const payload=body({adults:6,roomCount:2,includeMadinah:true,rooms:[a,{...a,id:'makkah:1'},b,{...b,id:'madinah:1'}],flights:[flight('out'),flight('back',back)]});
 const r=await send(payload);assert.equal(r.status,200,JSON.stringify(r.body));assert.equal(r.body.estimate.bookingAllowed,false);
 const only=await send({...payload,rooms:payload.rooms.slice(0,2)});assert.equal(only.status,200,JSON.stringify(only.body));assert.ok(r.body.estimate.totalPackagePrice>only.body.estimate.totalPackagePrice);
 const empty=await send({...payload,rooms:[]});assert.equal(empty.status,200,JSON.stringify(empty.body));assert.ok(only.body.estimate.totalPackagePrice>empty.body.estimate.totalPackagePrice);
 for(const invalid of [{...payload,roomCount:1},{...payload,rooms:[a,b]},{...payload,rooms:[a,{...a,id:'makkah:1',adults:2},b,{...b,id:'madinah:1'}]},{...payload,rooms:[a,{...a,id:'makkah:1',hotelId:'other'},b,{...b,id:'madinah:1'}]}]) assert.equal((await send(invalid)).status,400);
});
test('legacy one-room estimates and inferred room count remain compatible',async()=>{
 const r=await send(body({adults:6,flights:[flight('out')]}));assert.equal(r.status,200,JSON.stringify(r.body));assert.equal(r.body.estimate.bookingAllowed,false);
 assert.equal((await send(body({rooms:[room]}))).status,200);
});
