import SwiftUI

struct RootView: View {
    @EnvironmentObject private var auth: AuthStore
    @EnvironmentObject private var navigation: BusinessNavigationStore
    @EnvironmentObject private var appLock: BusinessAppLockStore
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            switch auth.state {
            case .checking: LaunchView()
            case .signedOut: LoginView()
            case .signedIn:
                BusinessTabView()
                    .allowsHitTesting(!appLock.isLocked && scenePhase == .active)
                if appLock.isLocked {
                    BusinessAppUnlockView()
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { BusinessDesign.background.ignoresSafeArea() }
        .tint(BusinessDesign.ink)
        .overlay {
            // Prevent displaying Business data in app-switcher snapshots.
            if auth.state == .signedIn && scenePhase != .active {
                BusinessAppPrivacyShield()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .iumrahBusinessSessionInvalidated)) { notification in
            auth.handleSessionInvalidated(token: notification.object as? String)
        }
        .onChange(of: auth.state) { _, state in
            if state == .signedIn, let login = auth.user?.login {
                appLock.bindAccount(login)
                Task { await auth.expireWeeklySessionIfNeeded() }
            } else if state == .signedOut {
                appLock.didSignOut()
                navigation.unreadChatCount = 0
                navigation.bookingFilterRequest = nil
                navigation.selection = .overview
                BusinessNotificationRoute.pendingOffer = nil
                BusinessNotificationRoute.pendingBooking = nil
                BusinessNotificationRoute.pendingChat = nil
            }
        }
        .onChange(of: auth.passwordLoginSerial) { _, _ in
            if let login = auth.user?.login { appLock.didPasswordLogin(account: login) }
        }
        .onChange(of: scenePhase) { _, next in
            switch next {
            case .active:
                appLock.sceneDidBecomeActive(authenticated: auth.state == .signedIn)
                Task {
                    await auth.expireWeeklySessionIfNeeded()
                    if auth.state == .signedIn { await BusinessNotifications.registerCurrentDeviceIfPossible() }
                }
            case .background:
                // Face ID temporarily moves a scene into .inactive. Only a real
                // background transition counts towards automatic PIN locking.
                appLock.sceneDidMoveToBackground()
            case .inactive:
                break
            @unknown default: break
            }
        }
    }
}

private struct LaunchView: View {
    @State private var pulse = false
    var body: some View {
        VStack(spacing: 18) {
            BusinessBrandLogo(height: 62)
                .frame(maxWidth: 300)
            Capsule()
                .fill(BusinessDesign.ink.opacity(0.85))
                .frame(width: pulse ? 72 : 28, height: 3)
                .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: pulse)
        }
        .onAppear { pulse = true }
    }
}
