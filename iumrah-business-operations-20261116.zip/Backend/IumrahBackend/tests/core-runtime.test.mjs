import test from 'node:test';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';
import core,{resolveCoreRoute} from '../core/index.js';import {createBackendRouter} from '../src/router.js';
const origin='https://iumrah-backend.helloiumrah.workers.dev';
const request=(path,method='GET',body,headers={})=>new Request(origin+path,{method,headers:{...headers,...(body?{'content-type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
const sql=new DatabaseSync(':memory:');
const db={prepare(query){let values=[];const api={bind(...args){values=args;return api;},async run(){return {meta:sql.prepare(query).run(...values)};},async first(){return sql.prepare(query).get(...values)||null;},async all(){return {results:sql.prepare(query).all(...values)};}};return api;},async batch(stmts){sql.exec('BEGIN');try{const results=[];for(const stmt of stmts)results.push(await stmt.run());sql.exec('COMMIT');return results;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const env={IUMRAH_CORE_CUTOVER_READY:'1',IUMRAH_CORE_PARITY_ATTESTATION:'v21:'+'a'.repeat(64),HOTELS_MEDIA:{},IUMRAH_SUPERADMIN_LOGIN:'operator',IUMRAH_SUPERADMIN_PASSWORD:'test-password',IUMRAH_SESSION_SECRET:'test-secret-for-fixtures',PACKAGE_QUOTE_SEAL_KEY:'test-quote-key',BOOKINGS_DB:db,HOTELS_DB:{},FLIGHTS_DB:{},PASSPORTS:{}};
const ctx={waitUntil(){}};const calls=[];const dummy={fetch(req){calls.push(new URL(req.url).pathname);return Response.json({ok:true,account:{},trips:[]});}};
const router=createBackendRouter({hotels:dummy,flights:dummy,packages:dummy,core,materializeBookingIdentity:async(_env,booking)=>({bookingID:booking.id,bookingNumber:1,pilgrimID:"00000001",tripID:"trip-fixture",status:"availability_check"}),verifyBookingQuote:async(booking,proof)=>{if(proof!=="verified-fixture")throw Error("QUOTE_PROOF_REQUIRED");return {quoteId:"server-fixture",totalUsd:booking.totalUsd,perPilgrimUsd:booking.perPilgrimUsd};}});const go=(p,m,b,h,e=env)=>router.fetch(request(p,m,b,h),e,ctx);
test('cutover guard refuses booking writes before explicit activation; foreign Origin rejected',async()=>{assert.equal((await go('/api/bookings','POST',{}, {}, {...env,IUMRAH_CORE_CUTOVER_READY:'0'})).status,503);assert.equal((await go('/api/bookings','POST',{}, {origin:'https://evil.example'})).status,403);});
test('staff login cookie is signed, secure and accepted by migrated session route',async()=>{const login=await go('/api/auth/staff/login','POST',{login:'operator',password:'test-password'});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie');assert.match(cookie,/HttpOnly/);assert.match(cookie,/Secure/);assert.match(cookie,/SameSite=lax/i);const session=await go('/api/auth/staff/session','GET',undefined,{cookie:cookie.split(';')[0]});assert.equal((await session.json()).authenticated,true);assert.equal((await go('/api/auth/staff/session','GET',undefined,{cookie:'iumrah_staff_session=wrong'})).status,401);});
test('booking create/read and admin list use the same D1; invalid token cannot read',async()=>{const booking={planId:'economy',totalUsd:1200,perPilgrimUsd:1200,input:{from:'Tashkent',originCode:'TAS',startDate:'2027-01-10',endDate:'2027-01-17',flexibleDays:0,hotelPreference:'3',includeMadinah:true,travelers:{adults:1,children:0,infants:0,rooms:1}},route:{originCode:'TAS',outboundDestination:'JED',returnOrigin:'MED'},stay:{totalDays:7,totalNights:6},customization:{},hotelNames:{makkah:'Example',madinah:'Example'},flight:'HY 335'};const before=await go('/api/bookings','POST',{booking,lang:'ru'});assert.equal(before.status,409);const made=await go('/api/bookings','POST',{booking,lang:'ru',quoteProof:"verified-fixture"});assert.equal(made.status,201,await made.clone().text());const data=await made.json();const id=data.booking.id;assert.ok(data.accessToken);assert.equal(data.identityReady,true);assert.equal(data.trip.pilgrimID,"00000001");assert.equal(data.trip.bookingNumber,1);assert.equal((await go('/api/bookings/'+id,'GET',undefined,{'x-booking-token':'x'.repeat(32)})).status,404);const read=await go('/api/bookings/'+id,'GET',undefined,{'x-booking-token':data.accessToken});assert.equal((await read.json()).booking.id,id);const login=await go('/api/auth/staff/login','POST',{login:'operator',password:'test-password'});const cookie=login.headers.get('set-cookie').split(';')[0];assert.equal((await go('/api/admin/bookings')).status,401);const list=await go('/api/admin/bookings','GET',undefined,{cookie});assert.equal((await list.json()).bookings[0].id,id);assert.equal(sql.prepare('SELECT COUNT(*) n FROM booking_events').get().n,1);});
test('static snapshot route is not swallowed by the dynamic package id route',()=>{assert.equal(resolveCoreRoute('/api/storefront/packages/snapshot').keys.length,0);assert.equal(resolveCoreRoute('/api/storefront/packages/123').keys[0],'id');});
test('account facade calls package module inside same router rather than legacy network',async()=>{const res=await go('/api/account/register/start','POST',{email:'fixture@example.test',locale:'ru'});assert.equal(res.status,200);assert.ok(calls.includes('/api/package/client/account/register/email/start'));});
test('airport API and real request adaptation',async()=>{const res=await go('/api/airports?q=Tashkent');assert.equal(res.status,200);assert.ok(Array.isArray((await res.json()).airports));});
test('public airport and catalog reads can reach the unified worker before private cutover; private mutations remain blocked',async()=>{const pending={...env,IUMRAH_CORE_CUTOVER_READY:'0'};assert.equal((await go('/api/airports?q=Tashkent','GET',undefined,{},pending)).status,200);assert.equal((await go('/api/account/session','GET',undefined,{},pending)).status,503);assert.equal((await go('/api/bookings','POST',{}, {},pending)).status,503);});


test('staff password cookie lasts seven days, carries signed authentication time, and expires without sliding',async()=>{
 const original=Date.now; const start=original();
 try {
  Date.now=()=>start;
  const login=await go('/api/auth/staff/login','POST',{login:'operator',password:'test-password'});
  const setCookie=login.headers.get('set-cookie');assert.match(setCookie,/Max-Age=604800/);
  const cookie=setCookie.split(';')[0];
  const session=await go('/api/auth/staff/session','GET',undefined,{cookie});
  assert.equal((await session.json()).user.authenticatedAt,start);
  Date.now=()=>start+6*24*60*60*1000;
  assert.equal((await go('/api/auth/staff/session','GET',undefined,{cookie})).status,200);
  Date.now=()=>start+7*24*60*60*1000+1000;
  assert.equal((await go('/api/auth/staff/session','GET',undefined,{cookie})).status,401);
  assert.equal((await go('/api/auth/staff/session','GET',undefined,{cookie:'iumrah_staff_session=%zz'})).status,401);
 } finally {Date.now=original;}
});

test('wrong staff password has its own error code; never issues a cookie',async()=>{
 const result=await go('/api/auth/staff/login','POST',{login:'operator',password:'wrong'});
 assert.equal(result.status,401);assert.equal((await result.json()).error,'INVALID_CREDENTIALS');assert.equal(result.headers.get('set-cookie'),null);
});

test('Business manual create: authorization, canonical cost, idempotency and read-only share',async()=>{
 const login=await go('/api/auth/staff/login','POST',{login:'operator',password:'test-password'});
 const cookie=login.headers.get('set-cookie').split(';')[0];
 const auth={cookie,'x-iumrah-business-session':'fixture-device'};
 const booking={planId:'standard',totalUsd:10,perPilgrimUsd:10,input:{from:'TAS',originCode:'TAS',startDate:'2027-03-01',endDate:'2027-03-08',flexibleDays:0,hotelPreference:'4',includeMadinah:false,travelers:{adults:2,children:0,infants:0,rooms:1}},route:{originCode:'TAS',outboundDestination:'JED',returnOrigin:'JED'},stay:{totalDays:8,totalNights:7,makkahCheckIn:'2027-03-01',makkahCheckOut:'2027-03-08',makkahNights:7},customization:{},hotelNames:{makkah:'Example'},flight:'HY 335',pilgrimProfile:{firstName:'Test',lastName:'Guest',phone:'+998901234567'},selection:{flightId:'f',makkahHotelId:'h',madinahHotelId:null},selectionDetails:{flight:{id:'f',airline:'HY',outboundOrigin:'TAS',outboundDestination:'JED',outboundDate:'2027-03-01',returnOrigin:'JED',returnDestination:'TAS',returnDate:'2027-03-08'},makkahHotel:{id:'h',name:'Example',stars:4,checkIn:'2027-03-01',checkOut:'2027-03-08'}}};
 const cost={flight:800,makkah:600,madinah:0,transfer:300,ziyarat:0,visa:0,guide:0,other:0,commission:5};
 const body={booking,cost,manualDetails:{makkah:{room:'Twin',rooms:1,meals:'Breakfast',privateCost:600},outbound:[{airline:'HY',number:'HY335',origin:'TAS',destination:'JED',privateCost:800}]},requestSecret:'ab'.repeat(32),lang:'ru',sendEmail:false};
 assert.equal((await go('/api/admin/bookings','POST',body)).status,403);
 assert.equal((await go('/api/admin/bookings','POST',body,{cookie})).status,403);
 assert.equal((await go('/api/bookings','POST',body,auth)).status,409);
 assert.equal((await go('/api/admin/bookings','POST',{...body,cost:{...cost,commission:-1}},auth)).status,400);
 const res=await go('/api/admin/bookings','POST',body,auth);assert.equal(res.status,201,await res.clone().text());const receipt=await res.json();assert.equal(receipt.totalUsd,1785);assert.equal(receipt.identityReady,true);
 const again=await go('/api/admin/bookings','POST',body,auth);assert.equal((await again.json()).bookingID,receipt.bookingID);
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM business_manual_bookings').get().n,1);
 const token=new URL(receipt.shareURL).hash.slice(1);assert.equal(token.length,64);
 assert.equal((await go('/api/bookings/share','POST',{token:'00'.repeat(32)})).status,404);
 const publicData=await (await go('/api/bookings/share','POST',{token})).json();assert.equal(publicData.id,receipt.bookingID);assert.equal(publicData.totalUsd,1785);assert.equal(publicData.makkah.name,'Example');assert.ok(!JSON.stringify(publicData).includes('+998'));assert.ok(!JSON.stringify(publicData).includes('commission'));
 assert.equal((await go('/api/bookings/'+receipt.bookingID,'GET',undefined,{'x-booking-token':token})).status,404);
 assert.match((await go('/api/bookings/share')).headers.get('content-security-policy'),/frame-ancestors 'none'/);
 assert.equal(publicData.details.makkah.room,'Twin');assert.equal(publicData.details.outbound[0].number,'HY335');assert.ok(!JSON.stringify(publicData).includes('privateCost'));
 assert.equal((await go('/api/admin/bookings/'+receipt.bookingID+'/manual')).status,403);
 const info=await (await go('/api/admin/bookings/'+receipt.bookingID+'/manual','GET',undefined,auth)).json();assert.equal(info.cost.commission,5);
 const rotate=await go('/api/admin/bookings/'+receipt.bookingID+'/share','POST',{},auth);assert.equal(rotate.status,200);const newToken=new URL((await rotate.json()).shareURL).hash.slice(1);assert.notEqual(newToken,token);
 assert.equal((await go('/api/bookings/share','POST',{token})).status,404);
 assert.equal((await go('/api/bookings/share','POST',{token:newToken})).status,200);
});
